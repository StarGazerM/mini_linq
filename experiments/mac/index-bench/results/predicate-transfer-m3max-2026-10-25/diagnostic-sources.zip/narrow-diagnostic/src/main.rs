#![recursion_limit="512"]
#![allow(dead_code,unused_imports,unused_macros)]
#[path="/Users/stargazermiao/workspace/mini_linq/target/mac-predicate-transfer/diagnostic_runtime.rs"] mod tpch_runtime;
#[path="/Users/stargazermiao/workspace/mini_linq/features/workloads/src/queries/retail/tpch/retail_d27.rs"] mod query;
use cq_load::ColumnAt;
use cq_storage::{AdaptiveKeySet,Build,Column,ExactMembership,I64Codec,Membership,PositionalRows,Selection,SelectionSummary};
use std::{collections::BTreeSet,hint::black_box,path::Path,time::Instant};
type KeySet=AdaptiveKeySet<i64,I64Codec,67108864>;
fn checksum<'a>(rows:impl Iterator<Item=(&'a i64,&'a i64,&'a i64)>,first:usize)->(usize,usize){rows.fold((0,0),|(n,s),r|(n+1,s.wrapping_add((r.0 as *const i64 as usize-first)/std::mem::size_of::<(i64,i64,i64)>()))) }
fn measure<'h,C>(name:&str,host:&'h [(i64,i64,i64)],selection:&Selection<&'h [(i64,i64,i64)]>,column:C,keys:&KeySet)->serde_json::Value
where C:Column<&'h [(i64,i64,i64)],Key=i64>, &'h [(i64,i64,i64)]:cq_storage::BlockRead<C> + cq_storage::rows::Rows<Row=(&'h i64,&'h i64,&'h i64)>, C:Copy {
    let first=&host[0].0 as *const i64 as usize;
    let input_ids:Vec<_>=selection.positions().map(|id|id.offset()).collect();
    let expected_ids:Vec<_>=selection.positions().filter(|id|keys.contains(&column.key(host,*id))).map(|id|id.offset()).collect();
    let expected=(expected_ids.len(),expected_ids.iter().sum::<usize>());
    let occupied:Vec<_>=host.blocks().filter(|block|host.block_positions(*block).any(|id|selection.contains(id))).collect();
    let visited:usize=occupied.iter().map(|b|host.block_positions(*b).count()).sum();
    let predicate=Membership(keys);
    let mut samples:[Vec<f64>;3]=std::array::from_fn(|_|Vec::new());
    for i in 0..23 { for j in 0..3 {let mode=(i+j)%3;let s=black_box(selection);let k=black_box(keys);let start=Instant::now();
        if mode==0 {
            let next=s.narrow(column,&predicate,SelectionSummary::PerBlock);black_box(&next);let ms=start.elapsed().as_secs_f64()*1e3;
            assert_eq!(checksum(next.rows(),first),expected);if i>=2{samples[mode].push(ms);}
        } else {
            let mut answer=(0_usize,0_usize);
            if mode==1 {for block in &occupied {for id in host.block_positions(*block).filter(|id|s.contains(*id)){if k.contains(&column.key(host,id)){answer.0+=1;answer.1=answer.1.wrapping_add(id.offset());}}}}
            else {for row in s.rows(){let offset=(row.0 as *const i64 as usize-first)/std::mem::size_of::<(i64,i64,i64)>();let id=host.positions().nth(offset).unwrap();if k.contains(&column.key(host,id)){answer.0+=1;answer.1=answer.1.wrapping_add(offset);}}}
            black_box(answer);let ms=start.elapsed().as_secs_f64()*1e3;assert_eq!(answer,expected);if i>=2{samples[mode].push(ms);}
        }
    }}
    let mut data=serde_json::Map::new();
    for (label,mut values) in ["actual_narrow_with_output_bitmap","current_position_enumeration_only","bitmap_word_row_enumeration_only"].into_iter().zip(samples){values.sort_by(f64::total_cmp);data.insert(label.into(),serde_json::json!({"median_ms":values[values.len()/2],"samples_ms":values}));}
    serde_json::json!({"name":name,"host_rows":host.len(),"block_rows":host.block_size().get(),"occupied_blocks":occupied.len(),"positions_visited_by_narrow":visited,"input_selected":input_ids.len(),"output_selected":expected.0,"output_id_checksum":expected.1,"selection_bytes":selection.retained_bytes(),"measurements":data})
}
fn main()->Result<(),Box<dyn std::error::Error>> {
    let args:Vec<_>=std::env::args().skip(1).collect();let d=query::load(Path::new(&args[0]),"default")?;
    let start=tpch_runtime::date("1995-01-01");let end=tpch_runtime::date("1995-04-01");
    let orders=KeySet::build(d.orders.iter().filter(|r|r.1>=start&&r.1<end).map(|r|(r.0,())));
    let parts=KeySet::build(d.part.iter().filter(|r|r.1=="Brand#12").map(|r|(r.0,())));
    let nations:BTreeSet<_>=d.nation.iter().filter(|r|r.1=="UNITED STATES").map(|r|r.0).collect();
    let suppliers=KeySet::build(d.supplier.iter().filter(|r|nations.contains(&r.1)).map(|r|(r.0,())));
    let host=d.lineitem.as_slice();
    let selected_orders=Selection::select(host,ColumnAt::<0>,&Membership(&orders),SelectionSummary::PerBlock);
    let selected_parts=selected_orders.narrow(ColumnAt::<1>,&Membership(&parts),SelectionSummary::PerBlock);
    let results=vec![measure("orders_to_parts",host,&selected_orders,ColumnAt::<1>,&parts),measure("parts_to_suppliers",host,&selected_parts,ColumnAt::<2>,&suppliers)];
    std::fs::write(&args[1],serde_json::to_vec_pretty(&results)?)?;println!("Verified selection occurrence IDs and sparse narrowing diagnostics.");Ok(())
}
