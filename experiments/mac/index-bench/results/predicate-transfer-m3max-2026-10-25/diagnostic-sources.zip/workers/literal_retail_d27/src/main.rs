#![recursion_limit="512"]
#[allow(unused_imports,unused_macros,dead_code)] #[path="/Users/stargazermiao/workspace/mini_linq/target/mac-predicate-transfer/diagnostic_runtime.rs"] mod tpch_runtime;
#[path="/Users/stargazermiao/workspace/mini_linq/target/mac-predicate-transfer/literal_sources/retail_d27.rs"] mod query;
#[path="/Users/stargazermiao/workspace/mini_linq/features/workloads/xtask/src/tpch/comparison.rs"] mod comparison;
include!("/Users/stargazermiao/workspace/mini_linq/target/mac-predicate-transfer/diagnostic_worker.rs");
