//! Explicit pipelines and the common typed shell for TPC-H-derived CQ kernels.
//! Query collection is timed; answer serialization and comparison are separate.

#[cfg(feature = "counters")]
pub type Dedup<T> = cq_storage::counters::DistinctSet<T>;
// Keep the recorded measurement alias aligned with the default provider.
// The counter build retains its explicit deterministic instrumentation state.
#[cfg(not(feature = "counters"))]
pub type Dedup<T> = cq_storage::HashSet<T>;

/// Expand the same authored CQ with an explicit sequence of public passes.
macro_rules! configuration {
    (default, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named default, $d, { $($stages)* }, { $($body)* });
        crate::tpch_runtime::configuration!(@named radix, $d, { $($stages)* }, [::cq_rewrites::radix_runs], { $($body)* });
        crate::tpch_runtime::configuration!(@named radix_retained, $d, { $($stages)* }, [::cq_rewrites::radix_runs, ::cq_rewrites::retain_lookups], { $($body)* });
        crate::tpch_runtime::configuration!(@named built_hash, $d, {
            $($stages)*
            physical = [::cq_rewrites::build_host_reads];
        }, { $($body)* });
        crate::tpch_runtime::configuration!(@named built_radix, $d, {
            $($stages)*
            physical = [::cq_rewrites::build_host_reads];
        }, [::cq_rewrites::radix_runs], { $($body)* });
        crate::tpch_runtime::configuration!(@named no_reduce, $d, {
            plan = ::mini_linq::passes::plan(no_reduce);
            $($stages)*
        }, { $($body)* });
    };
    (transfer, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named transfer, $d, { $($stages)* }, [], { $($body)* });
        crate::tpch_runtime::configuration!(@named transfer_radix, $d, { $($stages)* }, [::cq_rewrites::radix_runs], { $($body)* });
    };
    (le, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named le, $d, { $($stages)* }, [], { $($body)* });
        crate::tpch_runtime::configuration!(@named le_radix, $d, { $($stages)* }, [::cq_rewrites::radix_runs], { $($body)* });
    };
    (tuned, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named tuned, $d, { $($stages)* }, [], { $($body)* });
        crate::tpch_runtime::configuration!(@named tuned_radix, $d, { $($stages)* }, [::cq_rewrites::radix_runs], { $($body)* });
    };
    (advised, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named advised, $d, { $($stages)* }, [], { $($body)* });
        crate::tpch_runtime::configuration!(@named advised_radix, $d, { $($stages)* }, [::cq_rewrites::radix_runs], { $($body)* });
    };
    ($module:ident, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named $module, $d, { $($stages)* }, [], { $($body)* });
    };
    ($module:ident, $d:tt, { $($stages:tt)* }, [ $($extra:path),* ], { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named $module, $d, { $($stages)* }, [ $($extra),* ], { $($body)* });
    };
    (@named $module:ident, $d:tt, { $($stages:tt)* }, { $($body:tt)* }) => {
        crate::tpch_runtime::configuration!(@named $module, $d, { $($stages)* }, [], { $($body)* });
    };
    // Extra Structures rewrites run before the dedup retype shared by every configuration.
    (@named $module:ident, $d:tt, { $($stages:tt)* }, [ $($extra:path),* ], { $($body:tt)* }) => {
        mod $module {
            use super::*;
            #[allow(unused_macros)]
            macro_rules! query {
                (@structures; $d($d tokens:tt)*) => { ::mini_linq::compile! {
                    pipeline {
                        $($stages)*
                        structures = [$($extra,)* ::cq_rewrites::retype(dedup => crate::tpch_runtime::Dedup<_>)];
                        surface = [::cq_ext_aggregate::aggregate, ::cq_ext_correlated::correlated];
                        print = crate::tpch_runtime::capture_structures;
                    }
                    $d($d tokens)*
                } };
                (positional($d($d host:ident),*); $d($d tokens:tt)*) => { ::mini_linq::compile! {
                    pipeline {
                        $($stages)*
                        select = ::mini_linq::passes::select(positional($d($d host),*));
                        structures = [$($extra,)* ::cq_rewrites::retype(dedup => crate::tpch_runtime::Dedup<_>)];
                        surface = [::cq_ext_aggregate::aggregate, ::cq_ext_correlated::correlated];
                    }
                    $d($d tokens)*
                } };
                ($d($d tokens:tt)*) => { ::mini_linq::compile! {
                    pipeline {
                        $($stages)*
                        structures = [$($extra,)* ::cq_rewrites::retype(dedup => crate::tpch_runtime::Dedup<_>)];
                        surface = [::cq_ext_aggregate::aggregate, ::cq_ext_correlated::correlated];
                    }
                    $d($d tokens)*
                } };
            }
            $($body)*
        }
    };
}
pub(crate) use configuration;

/// Expand handwritten, possibly multistage kernels without changing their
/// default pipeline. Every query stage receives only the selected Structures
/// advice; host-side materialization remains inside the measured execution.
macro_rules! same_plan_kernel {
    ($d:tt; $($body:tt)*) => {
        crate::tpch_runtime::same_plan_kernel!(@named default, $d, {}, { $($body)* });
        crate::tpch_runtime::same_plan_kernel!(@named radix, $d, {
            structures = [::cq_rewrites::radix_runs];
        }, { $($body)* });
        crate::tpch_runtime::same_plan_kernel!(@named radix_retained, $d, {
            structures = [::cq_rewrites::radix_runs, ::cq_rewrites::retain_lookups];
        }, { $($body)* });
        pub fn run(data: &Data, config: &str) -> Vec<Answer> {
            match config {
                "default" => default::execute(data),
                "radix" => radix::execute(data),
                "radix_retained" => radix_retained::execute(data),
                _ => panic!("unknown configuration {config}"),
            }
        }
    };
    (@named $module:ident, $d:tt, { $($advice:tt)* }, { $($body:tt)* }) => {
        mod $module {
            use super::*;
            macro_rules! query {
                (pipeline { $d($d stages:tt)* } $d($d tokens:tt)*) => {
                    ::mini_linq::compile! {
                        pipeline { $d($d stages)* $($advice)* }
                        $d($d tokens)*
                    }
                };
            }
            $($body)*
        }
    };
}
pub(crate) use same_plan_kernel;

macro_rules! capture_structures {
    (pipeline {}; $($tokens:tt)*) => {
        stringify!($($tokens)*)
    };
}
pub(crate) use capture_structures;

/// Check complete canonical rows, not just row counts or configuration names.
pub(crate) fn same_plan_answers<T>(
    run: impl Fn(&str) -> Vec<T>,
    canonical: impl Fn(&[T]) -> Vec<Vec<String>>,
) -> Vec<T> {
    let baseline = run("default");
    let mut expected = canonical(&baseline);
    expected.sort();
    for config in ["radix", "radix_retained"] {
        let mut actual = canonical(&run(config));
        actual.sort();
        assert_eq!(actual, expected, "{config} differs from the default query");
    }
    baseline
}

macro_rules! candidate {
    (hypergraph; $d:tt; positional($($host:ident),*); $($body:tt)*) => {
        crate::tpch_runtime::configuration!(tuned, $d, { plan = ::cq_planners::order(hypergraph); select = ::mini_linq::passes::select(positional($($host),*)); }, { $($body)* });
    };
    (generic_smallest; $d:tt; positional($($host:ident),*); $($body:tt)*) => {
        crate::tpch_runtime::configuration!(tuned, $d, {
            plan = ::cq_planners::order(written, fine);
            select = ::mini_linq::passes::select(positional($($host),*));
            physical = [::cq_rewrites::canon_prefixes, ::cq_rewrites::smallest_intersections];
        }, { $($body)* });
    };
}
pub(crate) use candidate;

/// Declares each loading schema once, then reuses those exact declarations in
/// both CQ configurations and in `relation_loaders!`.
macro_rules! retail_kernel {
    (
        $d:tt;
        name $name:literal;
        sql $sql:literal;
        candidate $candidate:ident;
        $(advise plan($($advice:tt)*);)?
        $(extra $extra:ident;)?
        setup { $($setup:tt)* }
        relations {
            $(relation $relation:ident => $table:ident (
                $first:ident : $first_ty:ty $(, $column:ident : $ty:ty)* $(,)?
            );)*
        }
        $(derived { $($derived:tt)* })?
        answer($($out:ident : $out_ty:ty),+ $(,)?) :- $($body:tt)*
    ) => {
        pub const NAME: &str = $name;
        pub const SQL: &str = $sql;
        pub const CONFIGS: &[&str] = &["default", "radix", "radix_retained", "built_hash", "built_radix", "no-reduce", "transfer", "transfer_radix", "le", "le_radix", "le_runs", stringify!($candidate), "candidate_radix" $(, crate::tpch_runtime::advised_name!($($advice)*), "advised_radix")? $(, stringify!($extra), concat!(stringify!($extra), "_zone"))?];
        pub const EXPORTS: &[(&str, &str)] = &[$(
            (stringify!($table), concat!(stringify!($first) $(, ",", stringify!($column))*)),
        )*];
        pub struct Data { $(pub $table: Vec<($first_ty, $($ty,)*)>,)* $($extra: Option<ZoneData>,)? }
        pub type Answer = ($($out_ty,)+);
        ::mini_linq::relation_loaders! {
            $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
        }
        pub fn load(root: &std::path::Path, config: &str) -> Result<Data, Box<dyn std::error::Error>> {
            let data = Data { $($table: <relation_loader!($relation)>::parquet(
                root.join(concat!(stringify!($table), ".parquet")),
                ::cq_load::ParquetOptions::default(),
            )?,)* $($extra: None,)? };
            Ok(crate::tpch_runtime::extra_prepare!([$($extra)?]; data, config))
        }
        crate::tpch_runtime::configuration!(default, $d, { select = ::mini_linq::passes::select(positional($($relation),*)); }, {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        });
        // Robust predicate transfer: the same written order and Structures,
        // with forward and backward semijoin transfer before the join phase.
        crate::tpch_runtime::configuration!(transfer, $d, {
            plan = ::cq_planners::order(transfer);
            select = ::mini_linq::passes::select(positional($($relation),*));
        }, {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        });
        crate::tpch_runtime::configuration!(le, $d, {
            plan = ::cq_planners::order(le);
            select = ::mini_linq::passes::select(positional($($relation),*));
        }, {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        });
        // Lookup & Expand with sorted runs and shared lookups: integral-key
        // builds become sorted clustered runs with rank directories, and each
        // early lookup's cursor is the witness its later expansion forces.
        crate::tpch_runtime::configuration!(le_runs, $d, {
            plan = ::cq_planners::order(le);
            select = ::mini_linq::passes::select(positional($($relation),*));
        }, [::cq_rewrites::sorted_runs, ::cq_rewrites::retain_lookups], {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        });
        // The default plan with the kernel author's recorded plan advice.
        crate::tpch_runtime::advised_config!([$($($advice)*)?]; $d; positional($($relation),*);
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        );
        crate::tpch_runtime::candidate!($candidate; $d; positional($($relation),*);
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! {
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
            pub(super) fn structures() -> &'static str {
                query! { @structures;
                    struct Query;
                    $(relation $relation($first: $first_ty $(, $column: $ty)*);)*
                    $($($derived)*)?
                    answer($($out),+) :- $($body)*
                }
            }
        );
        crate::tpch_runtime::extra_zone!([$($extra)?]; $d;
            setup { $($setup)* }
            relations { $(relation $relation => $table ($first:$first_ty $(,$column:$ty)*);)* }
            derived { $($($derived)*)? }
            answer($($out),+) :- $($body)*
        );
        pub fn run(data: &Data, config: &str) -> Vec<Answer> {
            match config {
                "default" => default::run(data),
                "radix" => radix::run(data),
                "radix_retained" => radix_retained::run(data),
                "built_hash" => built_hash::run(data),
                "built_radix" => built_radix::run(data),
                "no-reduce" => no_reduce::run(data),
                "transfer" => transfer::run(data),
                "transfer_radix" => transfer_radix::run(data),
                "le" => le::run(data),
                "le_radix" => le_radix::run(data),
                "le_runs" => le_runs::run(data),
                stringify!($candidate) => tuned::run(data),
                "candidate_radix" => tuned_radix::run(data),
                $(crate::tpch_runtime::advised_name!($($advice)*) => advised::run(data),
                "advised_radix" => advised_radix::run(data),)?
                _ => crate::tpch_runtime::extra_run!([$($extra)?]; data, config),
            }
        }
                pub fn structures(config: &str) -> &'static str {
            match config {
                "default" => default::structures(),
                "radix" => radix::structures(),
                "radix_retained" => radix_retained::structures(),
                "built_hash" => built_hash::structures(),
                "built_radix" => built_radix::structures(),
                "transfer" => transfer::structures(),
                "transfer_radix" => transfer_radix::structures(),
                "le" => le::structures(),
                "le_radix" => le_radix::structures(),
                stringify!($candidate) => tuned::structures(),
                "candidate_radix" => tuned_radix::structures(),
                $(crate::tpch_runtime::advised_name!($($advice)*) => advised::structures(),
                "advised_radix" => advised_radix::structures(),)?
                _ => panic!("unknown structure capture configuration {config}"),
            }
        }
        pub fn canonical(rows: &[Answer]) -> Vec<Vec<String>> {
            rows.iter().map(|($($out,)+)| vec![$($out.to_string(),)+]).collect()
        }
    };
}
pub(crate) use retail_kernel;

/// Configuration name of a kernel's advised plan.
macro_rules! advised_name {
    ($($advice:tt)*) => {
        "advised"
    };
}
pub(crate) use advised_name;

macro_rules! advised_config {
    ([]; $d:tt; positional($($host:ident),*); $($body:tt)*) => {};
    ([$($advice:tt)+]; $d:tt; positional($($host:ident),*); $($body:tt)*) => {
        crate::tpch_runtime::configuration!(advised, $d, {
            plan = ::mini_linq::passes::plan($($advice)+);
            select = ::mini_linq::passes::select(positional($($host),*));
        }, { $($body)* });
    };
}
pub(crate) use advised_config;

pub(crate) fn date(value: &str) -> cq_load::Date {
    <cq_load::Date as cq_load::Load>::load(value).expect("authored ISO date")
}

thread_local! {
    static ZONE_COST: std::cell::Cell<(f64, usize)> = const { std::cell::Cell::new((0.0, 0)) };
}
pub fn zone_metrics() -> (f64, usize) {
    ZONE_COST.with(std::cell::Cell::get)
}
pub fn record_zones(start: std::time::Instant, bytes: usize) {
    ZONE_COST.with(|c| c.set((start.elapsed().as_secs_f64() * 1000.0, bytes)));
}
macro_rules! extra_run {
    ([]; $data:expr, $config:expr) => {
        panic!("unknown configuration {}", $config)
    };
    ([hypergraph]; $data:expr, $config:expr) => {
        match $config {
            "hypergraph" => hypergraph_extra::run($data),
            "hypergraph_zone" => hypergraph_zone::run($data),
            _ => panic!("unknown configuration {}", $config),
        }
    };
}
pub(crate) use extra_run;
macro_rules! extra_zone {
    ([]; $($rest:tt)*) => {};
    ([hypergraph]; $d:tt;
     setup { $($setup:tt)* }
     relations { $(relation $relation:ident => $table:ident ($first:ident:$first_ty:ty $(,$column:ident:$ty:ty)*);)* }
     derived { $($derived:tt)* }
     answer($($out:ident),+) :- $($body:tt)*
    ) => {
        pub struct ZoneData { $(pub $table: ::cq_load::ZoneRows<($first_ty, $($ty,)*), (::cq_load::MinMax<$first_ty>, $(::cq_load::MinMax<$ty>,)*)>,)* }
        #[allow(non_snake_case)]
        fn prepare_zones(data: &mut Data) {
            let start = std::time::Instant::now();
            $(let $relation = ::cq_load::ZoneRows::from_rows::<(::cq_load::MinMax<$first_ty>, $(::cq_load::MinMax<$ty>,)*)>(std::mem::take(&mut data.$table), std::num::NonZeroUsize::new(2048).unwrap());)*
            let bytes = 0 $(+ $relation.metadata_bytes())*;
            data.hypergraph = Some(ZoneData { $($table: $relation,)* });
            crate::tpch_runtime::record_zones(start, bytes);
        }
        crate::tpch_runtime::configuration!(hypergraph_extra, $d, {
            plan = ::cq_planners::order(hypergraph);
            select = ::mini_linq::passes::select(positional($($relation),*));
        }, {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                $(let $relation = data.$table.as_slice();)*
                $($setup)*
                query! { struct Query;
                    $(relation $relation($first:$first_ty $(,$column:$ty)*);)*
                    $($derived)*
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
        });
        crate::tpch_runtime::configuration!(hypergraph_zone, $d, {
            plan = ::cq_planners::order(hypergraph);
            select = ::mini_linq::passes::select(positional($($relation),*));
        }, {
            #[allow(non_snake_case)]
            pub(super) fn run(data: &Data) -> Vec<Answer> {
                let data = data.hypergraph.as_ref().expect("configuration loaded ZoneRows");
                $(let $relation = &data.$table;)*
                $($setup)*
                query! { struct Query;
                    $(relation $relation($first:$first_ty $(,$column:$ty)*);)*
                    $($derived)*
                    answer($($out),+) :- $($body)*
                }.map(|($($out,)+)| ($(::core::clone::Clone::clone($out),)+)).collect()
            }
        });
    };
}
pub(crate) use extra_zone;

// Workers load one configuration per process. Move decoded buffers into the
// explicitly selected host once; ordinary configurations retain their Vecs.
macro_rules! extra_prepare {
    ([]; $data:expr, $config:expr) => {{
        let _ = $config;
        $data
    }};
    ([hypergraph]; $data:expr, $config:expr) => {{
        let mut data = $data;
        if $config == "hypergraph_zone" {
            prepare_zones(&mut data);
        }
        data
    }};
}
pub(crate) use extra_prepare;
