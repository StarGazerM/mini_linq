use cq_planners_plan::{Planner,cq,ra};
use proc_macro::TokenStream;
#[proc_macro]
pub fn transfer_simplified(input:TokenStream)->TokenStream {
    cq_stage::pass::<cq::Program,ra::Program>(input.into(),|source,arguments| {
        if !arguments.is_empty() {return Err(syn::Error::new_spanned(arguments,"diagnostic pass takes no arguments"));}
        let normal=cq::normal::normalize(source)?;
        let target=cq_planners_plan::compile(source,Planner::Transfer)?;
        let simplified=cq_elaborate::simplify_reductions(&target)?;
        cq_planners_plan::check(source,&simplified)?;
        eprintln!("TRANSFER_DIAGNOSTIC acyclic={} definitions_before={} definitions_after={}",cq::hypergraph::Analysis::of(&normal).acyclic,target.plan.definitions.len(),simplified.plan.definitions.len());
        Ok(simplified)
    }).into()
}
