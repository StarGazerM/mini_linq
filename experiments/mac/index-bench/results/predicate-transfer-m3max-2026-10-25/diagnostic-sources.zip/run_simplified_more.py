import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parents[2]
out=root/'target/mac-predicate-transfer'
bench=root/'features/workloads/target/bench'
cases=json.loads((out/'simplified-more-cases.json').read_text())
build=root/'target/mac-slowdown-analysis/build'
# All compiler work and plan capture precede timing.
for label,case in cases.items():
    crate=out/'workers'/label
    for mode,features in [('plain',None),('counts','counters'),('profile','profile')]:
        command=['cargo','build','--release','--offline','--manifest-path',str(crate/'Cargo.toml'),'--target-dir',str(build)]
        if features: command+=['--locked','--features',features]
        with (crate/(mode+'-build.log')).open('w') as log:
            result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode: raise RuntimeError(f'{label}/{mode} failed; see {crate/(mode+"-build.log")}')
        shutil.copy2(build/'release'/('predicate-diag-'+label),crate/(mode+'-worker'))
    described=json.loads(subprocess.check_output([str(crate/'plain-worker'),'describe'],text=True))
    assert all(c in described['configurations'] for c in case['configs']) if 'configurations' in described else all(c in described['configs'] for c in case['configs'])
    plans=out/'plans'/label
    plans.mkdir(parents=True,exist_ok=True)
    for config in case['configs']:
        text=subprocess.check_output([str(crate/'plain-worker'),'structures',config],text=True)
        (plans/(config+'.structures')).write_text(text.replace(';',';\n'))
    print('Built and captured:',label,flush=True)

# Validate all configurations at the smaller scale before measurements.
for label,case in cases.items():
    crate=out/'workers'/label
    for config in case['configs']:
        folder=out/'verification'/label/config
        folder.mkdir(parents=True,exist_ok=True)
        oracle=bench/'verification/sf-0.1'/case['base']/'default/oracle.json'
        command=[str(crate/'plain-worker'),str(bench/'data/tpch-0.1'/case['base']),config,'0',str(folder/'answers.json'),str(folder/'metrics.json'),str(oracle)]
        with (folder/'worker.log').open('w') as log: subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    print('SF0.1 exact:',label,flush=True)

records=[]
for label,case in cases.items():
    crate=out/'workers'/label
    for config in case['configs']:
        folder=out/'runs'/label/config
        folder.mkdir(parents=True,exist_ok=True)
        oracle=bench/'runs/sf-1'/case['base']/'default/oracle.json'
        try:
            with (folder/'worker.log').open('w') as log:
                for mode,runs in [('plain',5),('counts',0),('profile',5)]:
                    env=dict(os.environ)
                    env.pop('CQ_OPERATOR_PROFILE',None);env.pop('CQ_OPERATOR_COUNTS',None)
                    if mode=='profile':env.update(CQ_OPERATOR_PROFILE='1',CQ_OPERATOR_COUNTS=str(folder/'counts.metrics.json'))
                    command=[str(crate/(mode+'-worker')),str(bench/'data/tpch-1'/case['base']),config,str(runs),str(folder/(mode+'.answers.json')),str(folder/(mode+'.metrics.json')),str(oracle)]
                    subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
            plain=json.loads((folder/'plain.metrics.json').read_text())
            counted=json.loads((folder/'counts.metrics.json').read_text())
            prof=json.loads((folder/'profile.metrics.json').read_text())
            assert prof['verified'] and prof['operator_rows']==counted['operator_rows']
            assert prof['bag_insertions']==counted['rows_copied']
            assert prof['set_insertions']+counted['candidate_insertions']==counted['distinct_insertions']
            record={'case':label,'query':case['base'],'configuration':config,'plain':plain,'counts':counted,'profile':prof,'timing_worker_sha256':hashlib.sha256((crate/'plain-worker').read_bytes()).hexdigest()}
            (folder/'operators.txt').write_text(prof['tree'])
            print(label,config,f'{plain["median_ms"]:.3f} ms',flush=True)
        except subprocess.TimeoutExpired:
            record={'case':label,'query':case['base'],'configuration':config,'censored':'worker exceeded 600 seconds including load, warmup, repeated execution and validation; not a query-time lower bound'}
            print('Censored:',label,config,flush=True)
        records.append(record)
        (out/'simplified-more-results.json').write_text(json.dumps(records,indent=2)+'\n')
print('Completed all current-plan comparisons.',flush=True)
